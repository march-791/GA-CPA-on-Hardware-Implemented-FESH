/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/dachuang/fesh_523/random.v";
static unsigned int ng1[] = {1U, 0U};
static unsigned int ng2[] = {0U, 0U};



static void Always_29_0(char *t0)
{
    char t8[8];
    char t32[32];
    char t33[32];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    char *t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    char *t30;
    char *t31;

LAB0:    t1 = (t0 + 3008U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(29, ng0);
    t2 = (t0 + 3824);
    *((int *)t2) = 1;
    t3 = (t0 + 3040);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(29, ng0);

LAB5:    xsi_set_current_line(30, ng0);
    t4 = (t0 + 1768);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = ((char*)((ng1)));
    memset(t8, 0, 8);
    t9 = (t6 + 4);
    t10 = (t7 + 4);
    t11 = *((unsigned int *)t6);
    t12 = *((unsigned int *)t7);
    t13 = (t11 ^ t12);
    t14 = *((unsigned int *)t9);
    t15 = *((unsigned int *)t10);
    t16 = (t14 ^ t15);
    t17 = (t13 | t16);
    t18 = *((unsigned int *)t9);
    t19 = *((unsigned int *)t10);
    t20 = (t18 | t19);
    t21 = (~(t20));
    t22 = (t17 & t21);
    if (t22 != 0)
        goto LAB9;

LAB6:    if (t20 != 0)
        goto LAB8;

LAB7:    *((unsigned int *)t8) = 1;

LAB9:    t24 = (t8 + 4);
    t25 = *((unsigned int *)t24);
    t26 = (~(t25));
    t27 = *((unsigned int *)t8);
    t28 = (t27 & t26);
    t29 = (t28 != 0);
    if (t29 > 0)
        goto LAB10;

LAB11:    xsi_set_current_line(34, ng0);
    t2 = (t0 + 1928);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    xsi_vlog_get_part_select_value(t33, 127, t4, 127, 1);
    t5 = (t0 + 2088);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    xsi_vlogtype_concat(t32, 128, 128, 2U, t7, 1, t33, 127);
    t9 = (t0 + 1928);
    xsi_vlogvar_wait_assign_value(t9, t32, 0, 0, 128, 0LL);

LAB12:    goto LAB2;

LAB8:    t23 = (t8 + 4);
    *((unsigned int *)t8) = 1;
    *((unsigned int *)t23) = 1;
    goto LAB9;

LAB10:    xsi_set_current_line(30, ng0);

LAB13:    xsi_set_current_line(31, ng0);
    t30 = (t0 + 1208U);
    t31 = *((char **)t30);
    t30 = (t0 + 1928);
    xsi_vlogvar_wait_assign_value(t30, t31, 0, 0, 128, 0LL);
    xsi_set_current_line(32, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 1768);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    goto LAB12;

}

static void Always_36_1(char *t0)
{
    char t7[8];
    char t20[8];
    char t30[8];
    char t52[8];
    char t62[8];
    char t84[8];
    char t94[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t8;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    char *t17;
    char *t18;
    char *t19;
    char *t21;
    char *t22;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    char *t35;
    char *t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    char *t47;
    unsigned int t48;
    char *t49;
    char *t50;
    char *t51;
    char *t53;
    char *t54;
    char *t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    char *t66;
    char *t67;
    char *t68;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    char *t79;
    unsigned int t80;
    char *t81;
    char *t82;
    char *t83;
    char *t85;
    char *t86;
    char *t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    char *t98;
    char *t99;
    char *t100;
    unsigned int t101;
    unsigned int t102;
    unsigned int t103;
    unsigned int t104;
    unsigned int t105;
    unsigned int t106;
    unsigned int t107;
    unsigned int t108;
    unsigned int t109;
    unsigned int t110;
    char *t111;
    unsigned int t112;
    char *t113;

LAB0:    t1 = (t0 + 3256U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(36, ng0);
    t2 = (t0 + 3840);
    *((int *)t2) = 1;
    t3 = (t0 + 3288);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(36, ng0);

LAB5:    xsi_set_current_line(37, ng0);
    t4 = (t0 + 1928);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t7, 0, 8);
    t8 = (t7 + 4);
    t9 = (t6 + 24);
    t10 = (t6 + 28);
    t11 = *((unsigned int *)t9);
    t12 = (t11 >> 29);
    t13 = (t12 & 1);
    *((unsigned int *)t7) = t13;
    t14 = *((unsigned int *)t10);
    t15 = (t14 >> 29);
    t16 = (t15 & 1);
    *((unsigned int *)t8) = t16;
    t17 = (t0 + 1928);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    memset(t20, 0, 8);
    t21 = (t20 + 4);
    t22 = (t19 + 24);
    t23 = (t19 + 28);
    t24 = *((unsigned int *)t22);
    t25 = (t24 >> 31);
    t26 = (t25 & 1);
    *((unsigned int *)t20) = t26;
    t27 = *((unsigned int *)t23);
    t28 = (t27 >> 31);
    t29 = (t28 & 1);
    *((unsigned int *)t21) = t29;
    t31 = *((unsigned int *)t7);
    t32 = *((unsigned int *)t20);
    t33 = (t31 ^ t32);
    *((unsigned int *)t30) = t33;
    t34 = (t7 + 4);
    t35 = (t20 + 4);
    t36 = (t30 + 4);
    t37 = *((unsigned int *)t34);
    t38 = *((unsigned int *)t35);
    t39 = (t37 | t38);
    *((unsigned int *)t36) = t39;
    t40 = *((unsigned int *)t30);
    t41 = (~(t40));
    *((unsigned int *)t30) = t41;
    t42 = *((unsigned int *)t36);
    t43 = (t42 != 0);
    if (t43 == 1)
        goto LAB6;

LAB7:
LAB8:    t46 = *((unsigned int *)t30);
    *((unsigned int *)t30) = (t46 & 1U);
    t47 = (t30 + 4);
    t48 = *((unsigned int *)t47);
    *((unsigned int *)t47) = (t48 & 1U);
    t49 = (t0 + 1928);
    t50 = (t49 + 56U);
    t51 = *((char **)t50);
    memset(t52, 0, 8);
    t53 = (t52 + 4);
    t54 = (t51 + 24);
    t55 = (t51 + 28);
    t56 = *((unsigned int *)t54);
    t57 = (t56 >> 4);
    t58 = (t57 & 1);
    *((unsigned int *)t52) = t58;
    t59 = *((unsigned int *)t55);
    t60 = (t59 >> 4);
    t61 = (t60 & 1);
    *((unsigned int *)t53) = t61;
    t63 = *((unsigned int *)t30);
    t64 = *((unsigned int *)t52);
    t65 = (t63 ^ t64);
    *((unsigned int *)t62) = t65;
    t66 = (t30 + 4);
    t67 = (t52 + 4);
    t68 = (t62 + 4);
    t69 = *((unsigned int *)t66);
    t70 = *((unsigned int *)t67);
    t71 = (t69 | t70);
    *((unsigned int *)t68) = t71;
    t72 = *((unsigned int *)t62);
    t73 = (~(t72));
    *((unsigned int *)t62) = t73;
    t74 = *((unsigned int *)t68);
    t75 = (t74 != 0);
    if (t75 == 1)
        goto LAB9;

LAB10:
LAB11:    t78 = *((unsigned int *)t62);
    *((unsigned int *)t62) = (t78 & 1U);
    t79 = (t62 + 4);
    t80 = *((unsigned int *)t79);
    *((unsigned int *)t79) = (t80 & 1U);
    t81 = (t0 + 1928);
    t82 = (t81 + 56U);
    t83 = *((char **)t82);
    memset(t84, 0, 8);
    t85 = (t84 + 4);
    t86 = (t83 + 24);
    t87 = (t83 + 28);
    t88 = *((unsigned int *)t86);
    t89 = (t88 >> 2);
    t90 = (t89 & 1);
    *((unsigned int *)t84) = t90;
    t91 = *((unsigned int *)t87);
    t92 = (t91 >> 2);
    t93 = (t92 & 1);
    *((unsigned int *)t85) = t93;
    t95 = *((unsigned int *)t62);
    t96 = *((unsigned int *)t84);
    t97 = (t95 ^ t96);
    *((unsigned int *)t94) = t97;
    t98 = (t62 + 4);
    t99 = (t84 + 4);
    t100 = (t94 + 4);
    t101 = *((unsigned int *)t98);
    t102 = *((unsigned int *)t99);
    t103 = (t101 | t102);
    *((unsigned int *)t100) = t103;
    t104 = *((unsigned int *)t94);
    t105 = (~(t104));
    *((unsigned int *)t94) = t105;
    t106 = *((unsigned int *)t100);
    t107 = (t106 != 0);
    if (t107 == 1)
        goto LAB12;

LAB13:
LAB14:    t110 = *((unsigned int *)t94);
    *((unsigned int *)t94) = (t110 & 1U);
    t111 = (t94 + 4);
    t112 = *((unsigned int *)t111);
    *((unsigned int *)t111) = (t112 & 1U);
    t113 = (t0 + 2088);
    xsi_vlogvar_wait_assign_value(t113, t94, 0, 0, 1, 0LL);
    goto LAB2;

LAB6:    t44 = *((unsigned int *)t30);
    t45 = *((unsigned int *)t36);
    *((unsigned int *)t30) = (t44 | t45);
    goto LAB8;

LAB9:    t76 = *((unsigned int *)t62);
    t77 = *((unsigned int *)t68);
    *((unsigned int *)t62) = (t76 | t77);
    goto LAB11;

LAB12:    t108 = *((unsigned int *)t94);
    t109 = *((unsigned int *)t100);
    *((unsigned int *)t94) = (t108 | t109);
    goto LAB14;

}

static void Cont_39_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 3504U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(39, ng0);
    t2 = (t0 + 1928);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3936);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    xsi_vlog_bit_copy(t9, 0, t4, 0, 128);
    xsi_driver_vfirst_trans(t5, 0, 127);
    t10 = (t0 + 3856);
    *((int *)t10) = 1;

LAB1:    return;
}


extern void work_m_00000000000076311104_1906350187_init()
{
	static char *pe[] = {(void *)Always_29_0,(void *)Always_36_1,(void *)Cont_39_2};
	xsi_register_didat("work_m_00000000000076311104_1906350187", "isim/t_isim_beh.exe.sim/work/m_00000000000076311104_1906350187.didat");
	xsi_register_executes(pe);
}
