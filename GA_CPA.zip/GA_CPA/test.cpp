#if 0
#include<iostream>
#include"NENC.h"
int main()
{
	U32 plain[4] = { 0x01234567,0x89ABCDEF,0xFEDCBA98,0x76543210 };
	U32 key[4] = { 0x01234567,0x89ABCDEF,0xFEDCBA98,0x76543210 };
	U32 cipher[4];
	for (size_t i = 0; i < 50; i++)
	{
		EnCryption(plain, key, cipher);
		EnCryption(cipher, key, plain);
	}
	
	
}
#endif