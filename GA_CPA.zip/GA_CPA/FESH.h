#pragma once
#ifndef      _FESH_H//���ļ���һ�£���.����_��ǰ���_��
#define     _FESH_H//�����ظ�������ʹ��if no define,define......endif

#include<iostream>
#include<algorithm>
#include<fstream>
#include<vector>
#include<random>
#include"ENC.h"
#include"util.h"
#define FILE_OPEN_ERROR 1
#define FILE_LENGTH_ERROR 2
const int traces = 20000;//��������
const int points = 3500;//ÿ��������
typedef uint32_t U32;//32λ�޷�����
typedef struct PNODE
{//�洢���νڵ�
	U32 key[4];
	U32 ex_key[4];//��չ������һ����Կ
	U32 plain[4];
	U32 cipher[4];
	U32 xor_inter[4];
	U32 xor_inter_xor[4];//���ϴ����һ�ֵ����ֵ
}PCK;
int single_hex2dec(char a)
{//�����ַ�16ת10����
	if (a >= '0' && a <= '9')
	{
		return a - '0';
	}
	else if (a >= 'A' && a <= 'F')
	{
		return a - 'A' + 10;
	}
	else if (a >= 'a' && a <= 'f')
	{
		return a - 'a' + 10;
	}
}
int HW_C(U32 x)
{//�������ĺ�����������
	int ans = 0;
	while (x)//ѭ������Ϊ1�ĸ���
	{
		ans++;
		x = x & (x - 1);//��ȥ���ұߵ�1
	}
	return ans;
}
void HEX2DEC(std::string str, U32* num)
{//U32 16���ַ�����ת10��32*4λ�޷��������飩
	num[0] = 0;
	num[1] = 0;
	num[2] = 0;
	num[3] = 0;
	for (int i = 0; i < 8; i++)
	{
		num[0] = num[0] * 16 + single_hex2dec(str[i]);
	}
	for (int i = 8; i < 16; i++)
	{
		num[1] = num[1] * 16 + single_hex2dec(str[i]);
	}
	for (int i = 16; i < 24; i++)
	{
		num[2] = num[2] * 16 + single_hex2dec(str[i]);
	}
	for (int i = 24; i < 32; i++)
	{
		num[3] = num[3] * 16 + single_hex2dec(str[i]);
	}
}
void DataRead(double x[][points], const char* file_path)
{//��ȡ��������
	
	std::ifstream in_file(file_path);
	char temp;
	double a;
	if (!in_file.is_open())
	{
		std::cout << "���ļ�ʧ�ܣ�" << file_path;
		exit(FILE_OPEN_ERROR);
	}//��ʧ�ܣ��˳�
	for (int i = 0; i < traces; i++)
	{
		for (int j = 0; j < points; j++)
		{
			in_file >> a;//��ȡ��������
			x[i][j] = a;
			if (j != points - 1) in_file >> temp;
			if (in_file.eof())
			{
				std::cout << "�ļ���ȡ����ĩβ��" << file_path;
				exit(FILE_LENGTH_ERROR);
			}
		}
	}
	
}
void Plain_Read(PCK* pck, const char* file_path)
{
	
	std::ifstream in_file(file_path);
	if (!in_file.is_open())
	{
		std::cout << "���ļ�ʧ�ܣ�" << file_path;
		exit(FILE_OPEN_ERROR);
	}
	std::string a;
	U32 num[4];
	int temp;
	for (int i = 0; i < traces; i++)
	{
		in_file >> temp;
		in_file >> a;
		HEX2DEC(a, pck[i].key);//��Կ
		in_file >> a;
		HEX2DEC(a, pck[i].plain);//����
		in_file >> a;
		HEX2DEC(a, num);//����
		in_file >> a;
		HEX2DEC(a, pck[i].cipher);//����
		pck[i].xor_inter[0] = pck[i].plain[0];
		pck[i].xor_inter[1] = pck[i].plain[1];
		pck[i].xor_inter[2] = pck[i].plain[2];
		pck[i].xor_inter[3] = pck[i].plain[3];
		if (in_file.eof())
		{
			std::cout << "�ļ���ȡ����ĩβ��" << file_path;
			exit(FILE_LENGTH_ERROR);
		}
	}
	for (int i = 1; i < traces; i++)
	{
		pck[i].xor_inter[0] = pck[i].xor_inter[0] ^ pck[i - 1].cipher[0];
		pck[i].xor_inter[1] = pck[i].xor_inter[1] ^ pck[i - 1].cipher[1];
		pck[i].xor_inter[2] = pck[i].xor_inter[2] ^ pck[i - 1].cipher[2];
		pck[i].xor_inter[3] = pck[i].xor_inter[3] ^ pck[i - 1].cipher[3];
	}
}

//��Կ��չ����

//й©�����
double Corrcoef(int* num, double x[][points], int loc)
{//����num��x[loc][points]���ϵ��
	double sumA, sumB, aveA, aveB;
	//���
	sumA = 0;
	sumB = 0;

	for (size_t i = 1; i < traces; i++)
	{
		sumA += num[i];
		sumB += x[i][loc];
	}
	//��ƽ��ֵ
	aveA = sumA / double(long(traces - 1));
	aveB = sumB / double(long(traces - 1));

	//�������ϵ��
	double R1 = 0, R2 = 0, R3 = 0;
	for (long i = 1; i < traces; i++)
	{
		R1 += (num[i] - aveA) * (x[i][loc] - aveB);
		R2 += pow((num[i] - aveA), 2);
		R3 += pow((x[i][loc] - aveB), 2);
	}
	return (R1 / sqrt(R2 * R3));
}
void corr_calc(double* Xor_corr, double x[][points], PCK* pck)
{
	int hw[traces];
	
	for (int j = 0; j < traces; j++)
	{
		hw[j] = HW_C(pck[j].xor_inter_xor[0]) + HW_C(pck[j].xor_inter_xor[1]) +
				HW_C(pck[j].xor_inter_xor[2]) + HW_C(pck[j].xor_inter_xor[3]);
	}
	for (int i = 0; i < points; i++)
	{
		Xor_corr[i] = Corrcoef(hw, x, i);
	}
		
	
}
void Dis_cout(PCK* pck)
{
	for (int i = 0; i < traces; i++)
	{
		pck[i].ex_key[0] = pck[i].key[0];
		pck[i].ex_key[1] = pck[i].key[1];
		pck[i].ex_key[2] = pck[i].key[2];
		pck[i].ex_key[3] = pck[i].key[3];
		
	}//��Կ��չ
	
	for (int i = 0; i < traces; i++)
	{
		pck[i].xor_inter_xor[0] = pck[i].xor_inter[0] ^ pck[i].key[0];
		pck[i].xor_inter_xor[1] = pck[i].xor_inter[1] ^ pck[i].key[1];
		pck[i].xor_inter_xor[2] = pck[i].xor_inter[2] ^ pck[i].key[2];
		pck[i].xor_inter_xor[3] = pck[i].xor_inter[3] ^ pck[i].key[3];
	}
}
//void Dis_cout(PCK* pck)
//{
//	for (int i = 0; i < traces; i++)
//	{
//		pck[i].ex_key[0] = pck[i].key[0];
//		pck[i].ex_key[1] = pck[i].key[1];
//		pck[i].ex_key[2] = pck[i].key[2];
//		pck[i].ex_key[3] = pck[i].key[3];
//
//	}//��Կ��չ
//	for (int i = 1; i < traces; i++)
//	{
//		pck[i].xor_inter_xor[0] = pck[i].xor_inter[0] ;
//		pck[i].xor_inter_xor[1] = pck[i].xor_inter[1] ;
//		pck[i].xor_inter_xor[2] = pck[i].xor_inter[2] ;
//		pck[i].xor_inter_xor[3] = pck[i].xor_inter[3] ;
//	}
//}
int Leak_point(PCK* pck, double trace_points[][points], const char* file_path)
{
	double Xor_corr[points];//��������ϵ��
	Dis_cout(pck);
	corr_calc(Xor_corr, trace_points, pck);//���������ϵ��
	std::ofstream out(file_path, std::ios::out);
	if (!out.is_open())
	{
		std::cout << "���ļ�ʧ�ܣ�" << file_path;
		exit(FILE_OPEN_ERROR);
	}
	
	std::vector<int> a;
	//int sum = 0;
	for (int i = 0; i < points; i++)
	{
		out << Xor_corr[i] << std::endl;
		
		//if (Xor_corr[i] <-0.6) a.push_back(i);
	}
	out.close();
	/*for (int i = 0; i < a.size(); i++)
	{
		sum += a[i];
	}
	return sum / a.size();*/
	double min=0;
	int min_loc=0;
	for (int i = 0; i < points; i++)
	{
		if (Xor_corr[i] < min)
		{
			min_loc = i;
			min = Xor_corr[i];
		}
	}

	return min_loc;
}
#endif