#pragma once
#ifndef      _ENC_H//���ļ���һ�£���.����_��ǰ���_��
#define     _ENC_H//�����ظ�������ʹ��if no define,define......endif
#include <iostream>
using namespace std;
#define N 16             /* FESH-128-128 ������ 16 �� */
#define Word 32          /* 128 ���ط������Ϊ 32 ���� */
#define Cst0 0x243F6A88  /* FESH-128-128 �ĳ��� Cst0ֵ */
#define ROL32_r(x,a) (((x)<<(a))|((x)>>(Word-(a))))  /* ѭ����λ */
typedef uint32_t U32;//32λ�޷�����
const int a[8] = { 29, 13, 4, 21,
                  15, 19, 25, 6 };    /* FESH-128-128 �ֺ������ֻ��������õĲ��� */
const int a_k[4] = { 24, 30, 7, 18 };  /* FESH-128-128 ��Կ�������ֻ��������õĲ��� */



void Equal(U32* in, U32* out);           /* 4*32bits ���� in1 ��ֵ�� out */
void Xor(U32* in1, U32* in2, U32* out);  /* 4*32bits ���� in1, in2 ��λ���ó� out */
void SubNibble(U32* x);              /* S ���滻 */
void MixWord(U32* x);                /* �ֻ�� */
void ARC(U32* rk, U32 Cst, U32* x);  /* ������ */
void SubNibble_K(U32* x);            /* �� S �� */
void MixWord_K(U32* x);              /* ��Կ�ֻ�� */
void F(U32* rk, U32 Cst);            /* ��Կ���� */
void EnCryption(U32* plaintext, U32* key, U32* ciphertext);    /* �� FESH-128-128 ���� */



void Equal(U32* in, U32* out) {

    for (int i = 0; i < 4; ++i)
        out[i] = in[i];

}

void Xor(U32* in1, U32* in2, U32* out) {

    for (int i = 0; i < 4; ++i)
        out[i] = in1[i] ^ in2[i];

}

void SubNibble(U32* x) {

    U32 r[5];

    r[0] = x[1];
    r[1] = x[2];
    r[2] = x[0];
    r[3] = x[3];
    r[4] = r[0] | r[2];
    r[1] = r[1] ^ r[4];
    r[4] = r[3] | r[1];
    r[2] = r[2] ^ r[4];
    r[1] = r[1] ^ r[3];
    r[4] = r[0] & r[2];
    r[3] = r[3] ^ r[4];
    r[2] = r[2] ^ r[0];
    r[0] = r[0] ^ r[1];
    r[4] = ~r[2];
    r[4] = r[4] | r[3];
    r[1] = r[1] ^ r[4];
    r[4] = ~r[0];
    r[4] = r[4] | r[1];
    r[3] = r[3] ^ r[4];
    x[0] = r[2];
    x[1] = r[0];
    x[2] = r[1];
    x[3] = r[3];

}
void invSubNibble(U32* x) {

    U32 r[5];

    r[0] = x[0];
    r[1] = x[1];
    r[2] = x[3];
    r[3] = x[2];
    r[0] = r[0] ^ r[1];
    r[1] = r[1] ^ r[3];
    r[4] = r[0] | r[1];
    r[2] = r[2] ^ r[4];
    r[1] = r[1] ^ r[2];
    r[1] = r[1] ^ r[3];
    r[4] = r[1] & r[3];
    r[0] = r[0] ^ r[4];
    r[4] = r[3] ^ r[2];
    r[3] = ~r[4];
    r[2] = r[2] ^ r[0];
    r[4] = r[1] | r[2];
    r[3] = r[3] ^ r[4];
    r[4] = r[0] & r[3];
    r[2] = r[2] ^ r[4];
    x[0] = r[0];
    x[1] = r[3];
    x[2] = r[2];
    x[3] = r[1];

}
void MixWord(U32* x) {

    U32 t;
    U32 y[4];

    x[0] = x[0] ^ ROL32_r(x[1], a[0]);
    x[3] = x[3] ^ ROL32_r(x[2], a[1]);
    x[1] = x[1] ^ ROL32_r(x[0], a[2]);
    x[2] = x[2] ^ ROL32_r(x[3], a[3]);
    t = x[1];
    x[1] = x[2];
    x[2] = t;
    x[0] = x[0] ^ ROL32_r(x[1], a[4]);
    x[3] = x[3] ^ ROL32_r(x[2], a[5]);
    x[1] = x[1] ^ ROL32_r(x[0], a[6]);
    x[2] = x[2] ^ ROL32_r(x[3], a[7]);
    y[0] = x[0];
    y[1] = x[2];
    y[2] = x[1];
    y[3] = x[3];
    x[0] = y[0];
    x[1] = y[1];
    x[2] = y[2];
    x[3] = y[3];

}

void ARC(U32* rk, U32 Cst, U32* x) {

    U32 y[4] = { Cst, 0, 0, 0 };

    Xor(rk, y, x);

}

void SubNibble_K(U32* x) {

    U32 r[5];

    r[3] = x[0];
    r[0] = x[1];
    r[1] = x[2];
    r[2] = x[3];
    r[1] = ~r[1];
    r[4] = r[1] | r[3];
    r[2] = r[2] ^ r[4];
    r[4] = r[0] | r[1];
    r[3] = r[3] ^ r[4];
    r[4] = ~r[0];
    r[4] = r[4] & r[2];
    r[1] = r[1] ^ r[4];
    r[4] = r[2] & r[3];
    r[0] = r[0] ^ r[4];
    x[0] = r[1];
    x[1] = r[3];
    x[2] = r[2];
    x[3] = r[0];

}

void MixWord_K(U32* x) {

    U32 y[4];

    x[0] = x[0] ^ ROL32_r(x[1], a_k[0]);
    x[3] = x[3] ^ ROL32_r(x[2], a_k[1]);
    x[1] = x[1] ^ ROL32_r(x[0], a_k[2]);
    x[2] = x[2] ^ ROL32_r(x[3], a_k[3]);
    y[0] = x[2];
    y[1] = x[0];
    y[2] = x[3];
    y[3] = x[1];
    x[0] = y[0];
    x[1] = y[1];
    x[2] = y[2];
    x[3] = y[3];

}

void F(U32* rk, U32 Cst) {

    U32 x[4];

    ARC(rk, Cst, x);                     /* XK = ARC(RKi��Csti-1)= RKi �� (Csti-1,0,0,0) */
    SubNibble_K(x);                      /* YK = SubNibble_K (XK)                       */
    MixWord_K(x);                        /* ZK= MixWord_K (YK)                          */
    Equal(x, rk);                 /* RKi+1= ZK                                   */

}

void EnCryption(U32* plaintext, U32* key, U32* ciphertext) {  /**/

    U32 Cst = Cst0;
    U32 x[4], rk[4];

    Equal(key, rk);               /* RK0=K                               */
    Xor(plaintext, rk, x);  /* X0=P �� RK0                          */
    for (int i = 0; i < N; ++i) {          /* for i=0 to N-1                      */
        /* �� r=i+1 ��(r=1,2,��,N) */       /* {
                                         */
        F(rk, ROL32_r(Cst, i));      /*     RKi=F(RKi-1��Csti-1), i=1, ��, N */
        
        SubNibble(x);                    /*     Yi = SubNibble (Xi)             */
        

        MixWord(x);                      /*     Zi = MixWord (Yi)               */
        //std::cout << "w:" << std::hex << x[0] << x[1] << x[2] << x[3] << std::endl;
        Xor(x, rk, x);      /*     Xi+1 =Zi�� RKi+1                 */
    }                                     /* }                                   */
    Equal(x, ciphertext);         /* C=XN                                */
    //std::cout <<"cipher:" << std::hex << x[0] << x[1] << x[2] << x[3] << std::endl;
}
#endif