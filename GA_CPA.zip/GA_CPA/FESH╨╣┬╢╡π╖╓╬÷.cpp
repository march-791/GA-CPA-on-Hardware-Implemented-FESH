#if 1
#include<iostream>
#include<algorithm>
#include"FESH.h"
#include"GA.h"
#include <set>


# include<ctime>
double trace_points[traces][points];//����
PCK pck[traces];

double trace_points_l[mNum][points];//����
PCK pck_l[mNum];
void random_pick(int num)
{
	srand((unsigned)time(NULL));
	vector<int> indexs;
	for (int i = 1; i < traces; i++)
	{
		indexs.push_back(i);
	}
	random_shuffle(indexs.begin(), indexs.end());
	int i = 0;
	for (auto it = indexs.begin(); it != indexs.end(); ++it) {
		if (i >= num) {
			break;
		}
		for (int j = 0; j < points; j++)
		{
			trace_points_l[i][j] = trace_points[*it][j];

		}
		pck_l[i].cipher[0] = pck[*it].cipher[0];
		pck_l[i].cipher[1] = pck[*it].cipher[1];
		pck_l[i].cipher[2] = pck[*it].cipher[2];
		pck_l[i].cipher[3] = pck[*it].cipher[3];

		pck_l[i].key[0] = pck[*it].key[0];
		pck_l[i].key[1] = pck[*it].key[1];
		pck_l[i].key[2] = pck[*it].key[2];
		pck_l[i].key[3] = pck[*it].key[3];

		pck_l[i].plain[0] = pck[*it].plain[0];
		pck_l[i].plain[1] = pck[*it].plain[1];
		pck_l[i].plain[2] = pck[*it].plain[2];
		pck_l[i].plain[3] = pck[*it].plain[3];

		pck_l[i].xor_inter[0] = pck[*it].xor_inter[0];
		pck_l[i].xor_inter[1] = pck[*it].xor_inter[1];
		pck_l[i].xor_inter[2] = pck[*it].xor_inter[2];
		pck_l[i].xor_inter[3] = pck[*it].xor_inter[3];
		i++;
	}

}
int main()
{

	
	std::cout << "���ڶ�ȡ�ļ�...." << std::endl;

	//////masked
	DataRead(trace_points,"D:\\sidechannel\\research\\FESH����\\dachuang\\����\\����ǰ-��\\traces&data\\shifted_data.csv");//��ȡ����
	Plain_Read(pck,"D:\\sidechannel\\research\\FESH����\\dachuang\\����\\����ǰ-��\\traces&data\\Plaintext.csv");//��ȡ���ġ����ġ���Կ
	std::cout << "�ļ���ȡ�ɹ���" << std::endl;
	int lpoint = Leak_point(pck, trace_points, "D:\\sidechannel\\research\\FESH����\\dachuang\\����\\����ǰ-��\\traces&data\\coef_xor.csv");
	//
 	std::cout <<"�²�й¶�㣺" << lpoint <<std::endl;//Ѱ��й©��
	std::cout << "���ڳ���������ȷ��...." << std::endl;
	int try_time = 100;
	int num = 5000;
	std::ofstream out("D:\\sidechannel\\research\\FESH����\\dachuang\\����\\����ǰ-��\\traces&data\\HD_T_Double_c45_m80_100iter_acc.csv", std::ios::out);
	if (!out.is_open())
	{
		std::cout << "���ļ�ʧ�ܣ�" << "D:\\sidechannel\\research\\FESH����\\dachuang\\����\\����ǰ-��\\traces&data\\HD_T_Double_c45_m80_100iter_acc.csv";
		exit(FILE_OPEN_ERROR);
	}
	for (int num = 2000; num < 5001; num+=1000)
	{
		
		int count = 0;
		int re_sum = 0;
		clock_t  Begin = clock();//��ʼ��ʱ
		for (int i = 0; i < try_time; i++)
		{
			random_pick(num);
			int re = GA(trace_points_l, pck_l, lpoint, 0.08, 0.45, num);

			////
			if (re == 0) {
				count++;
			}
		}
		clock_t  End = clock();//��ʼ��ʱ
		cout << num<<"�����������ʱ��Ϊ��" << double(End - Begin) / CLK_TCK << "s" << endl;
		cout << count;
	}
	
	//out << "num" << "," << "count" << "," << "re_sum" << endl;
	//cout << "num" << "," << "count" << "," << "re_sum" << endl;
	//for (int num = 100; num < 3000; num+=100)
	//{
	//	random_pick(num);
	//	int count = 0;
	//	int re_sum = 0;
	//	for (int i = 0; i < try_time; i++)
	//	{
	//		random_pick(num);
	//		int re = GA(trace_points_l, pck_l, lpoint, 0.08, 0.45, num);
	//		re_sum += re;
	//		////
	//		if (re == 0) {
	//			count++;
	//		}
	//	}
	//	out << num << "," << count<<","<< re_sum << endl;
	//	cout << num << "," << count<<","<< re_sum << endl;
	//}
	

	//����pm,pc
	//double pc = 0.05;
	//out << "pc" << "," << "pm" << "," << "HD" << "," << "acc" << endl;
	//for (int c = 0; c < 19; c++)
	//{
	//	double pm = 0.005;
	//	for (int m = 0; m < 19; m++)
	//	{
	//		int count = 0;
	//		int acc_count = 0;
	//		for (int i = 0; i < try_time; i++)
	//		{
	//			random_pick(num);
	//			int re = GA(trace_points_l, pck_l, lpoint, pm,pc, num);
	//			
	//			////
	//			if (re == 0) {
	//				acc_count += 1;
	//			}
	//			count += re;
	//		}
	//		out << pc << "," << pm << "," << double(count)/ try_time << "," << double(acc_count) / try_time << endl;
	//		cout << pc << "," << pm << "," << double(count) / try_time << "," << double(acc_count) / try_time << endl;
	//		pm += 0.005;
	//	}
	//	pc += 0.05;
	//}
	
	/*U32 k[4] = { 0x01234567,0x89ABCDEF,0xFEDCBA98,0x76543210 };
	U32 p[4] = { 0x564843A0,0x76ED25F3,0x981EF95E,0x11127B27 };
	U32 c[4];
	U32 c2[4];
	Double_Point_Cross_Over(c, c2, k, p);*/
	/*EnCryption(p, k, c);
	std::cout << std::hex << c[0] << c[1] << c[2] << c[3];*/
}


#endif